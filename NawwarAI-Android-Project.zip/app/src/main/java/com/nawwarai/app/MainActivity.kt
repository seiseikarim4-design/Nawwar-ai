package com.nawwarai.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Ink = Color(0xFF101522)
private val Panel = Color(0xFF1A2233)
private val Purple = Color(0xFF8B6CFF)
private val Mint = Color(0xFF5DE0C1)
private val Muted = Color(0xFF9AA6BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NawwarApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NawwarApp() {
    var selected by remember { mutableStateOf("توليد صورة") }
    var prompt by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var notice by remember { mutableStateOf("اختر أداة واكتب ما تريد إنشاؤه أو تعديله.") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { imageUri = it }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple, secondary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Mint)), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Ink, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("نوّر AI", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("استوديو الصور بالذكاء الاصطناعي", color = Muted, fontSize = 12.sp)
                    }
                    Surface(color = Color(0xFF253A3B), shape = RoundedCornerShape(50)) {
                        Text("مجاني", color = Mint, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(25.dp))
                Box(
                    Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(0xFF34285D), Color(0xFF183C45))),
                        RoundedCornerShape(24.dp)
                    ).padding(20.dp)
                ) {
                    Column {
                        Text("خيالك يبدأ من هنا", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(7.dp))
                        Text("أنشئ صوراً مذهلة، حسّن صورك، وامنحها أسلوباً جديداً.", color = Color(0xFFD3D8E7), fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoFixHigh, null, tint = Mint)
                            Spacer(Modifier.width(7.dp))
                            Text("أدوات إبداعية في مكان واحد", color = Mint, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(Modifier.height(25.dp))
                Text("ماذا تريد أن تفعل؟", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                val modes = listOf(
                    Triple("توليد صورة", Icons.Default.AutoAwesome, "من وصف نصي"),
                    Triple("تحسين صورة", Icons.Default.HighQuality, "وضوح وتفاصيل"),
                    Triple("تغيير الصورة", Icons.Default.Tune, "تعديل العناصر"),
                    Triple("تغيير الأسلوب", Icons.Default.Brush, "أنمي وفني وواقعي")
                )
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    modes.chunked(2).forEach { rowModes ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            rowModes.forEach { (name, icon, subtitle) ->
                                val active = selected == name
                                Column(
                                    Modifier.weight(1f).border(
                                        1.dp, if (active) Purple else Color(0xFF303A4D),
                                        RoundedCornerShape(18.dp)
                                    ).background(if (active) Color(0xFF292443) else Panel, RoundedCornerShape(18.dp))
                                        .clickable { selected = name }
                                        .padding(14.dp)
                                ) {
                                    Icon(icon, null, tint = if (active) Mint else Purple, modifier = Modifier.size(25.dp))
                                    Spacer(Modifier.height(10.dp))
                                    Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(subtitle, color = Muted, fontSize = 11.sp)
                                }
                            }
                            if (rowModes.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Text(if (selected == "توليد صورة") "صف الصورة التي تتخيلها" else "الصورة التي تريد العمل عليها", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                if (selected != "توليد صورة") {
                    Surface(
                        onClick = { picker.launch("image/*") },
                        color = Panel, shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3B465B))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (imageUri != null) {
                                AsyncImage(model = imageUri, contentDescription = "الصورة المختارة", modifier = Modifier.fillMaxSize())
                            } else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AddPhotoAlternate, null, tint = Mint, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("اضغط لاختيار صورة من جهازك", color = Color.White)
                                Text("JPG أو PNG أو WEBP", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(), minLines = 3,
                    placeholder = { Text(if (selected == "توليد صورة") "مثال: مدينة مستقبلية وقت الغروب، تفاصيل فائقة، إضاءة سينمائية..." else "اكتب التعديلات المطلوبة بالتفصيل...") },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF3B465B),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
                    )
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        notice = when {
                            prompt.isBlank() -> "اكتب وصفاً أو تعليمات أولاً."
                            selected != "توليد صورة" && imageUri == null -> "اختر صورة من جهازك أولاً."
                            else -> "واجهة التطبيق جاهزة. لتفعيل المعالجة الفعلية، اربط التطبيق بخادم ذكاء اصطناعي موثوق كما هو موضح في README."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("ابدأ الآن", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.height(10.dp))
                Text(notice, color = Mint, fontSize = 12.sp)
                Spacer(Modifier.height(25.dp))
                HorizontalDivider(color = Color(0xFF303A4D))
                Spacer(Modifier.height(15.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, null, tint = Mint, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("صورك تبقى على جهازك حتى تختار مشاركتها مع خدمة معالجة.", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
